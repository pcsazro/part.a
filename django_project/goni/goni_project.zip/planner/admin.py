from django.contrib import admin

# Register your models here.
from planner.models import *

admin.site.register(PlannerD)
admin.site.register(PlannerM)
admin.site.register(Place)
